
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Antria Bank</title>
        <link rel="stylesheet" href="../font-awesome-4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../dashboard.css" rel="stylesheet">
    
  </head>
  
<script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<br><br><br>
  <body>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#">Antrian Bank</a>



    </nav>
    

    <div class="container-fluid">
      <div class="row">
        <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar"><br><br><br>
<div class="list-group panel">

<a href="landingpage.php" class="list-group-item collapsed" data-parent="#sidebar"><i class="fa fa-dashboard"></i> <span class="hidden-sm-down">Beranda</span></a>

                <a href="#menu1" class="list-group-item collapsed" data-toggle="collapse" data-parent="#sidebar" aria-expanded="false"><i class="fa fa-credit-card-alt"></i> <span class="hidden-sm-down">Info</span> </a>
                <div class="collapse" id="menu1">
                    <a href="tabungan.php" class="list-group-item"><i class="fa fa-credit-card"></i> <span class="hidden-sm-down">Buka Rekening </a>
                  <a href="layanan.php" class="list-group-item collapsed" data-parent="#sidebar"><i class="fa fa-lock"></i> <span class="hidden-sm-down">Layanan</span></a>
                </div>
                
                 <a href="index.php" class="list-group-item collapsed" data-parent="#sidebar"><i class="fa fa-user-circle-o"></i> <span class="hidden-sm-down">Keluar</span></a>
            </div>


        </nav>

<main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">


<div class="card text-center">
  <div class="card-header">
    PILIH 
  </div>
  <div class="card-body">
    <h4 class="card-title"></h4>

  
    </script>
<center><div class="container">
<div class="row">
  <div class="col-md-6">
    <div class="card" style="width: 20rem;">
        <div class="card-body">
          <h4 class="card-title">CUSTOMER SERVICE</h4>
          <a href="../client/index.php" class="btn btn-primary">Pilih</a>
        </div>
      </div>
    </div>
 
  </script>
<center><div class="container">
<div class="row">
  <div class="col-md-6">
    <div class="card" style="width: 20rem;">
        <div class="card-body">
          <h4 class="card-title">TELLER</h4>
          <a href="../client/index2.php" class="btn btn-primary">Pilih</a>
        </div>
      </div>
    </div>


      </div>
    </div> 

</div>  
</div>
</center>

<br>



</div>
</main>


  </body>
</html>
